#!/bin/bash
# B10-lockdown-enforcement.sh
# Tests LOCKDOWN posture with real enforcement
# WARNING: This freezes processes, remounts rootfs read-only, quenches egress
# Break-glass is triggered automatically after 5 seconds
# Run as: sudo bash B10-lockdown-enforcement.sh
set -euo pipefail

LOG="/tmp/adms-B10.log"
echo "=== B10: LOCKDOWN Enforcement Test ===" | tee "$LOG"
echo "Started: $(date)" | tee -a "$LOG"
echo "WARNING: LOCKDOWN will be applied for ~5 seconds then auto-reset" | tee -a "$LOG"

# Kill any existing controller
pkill -f adms-controller 2>/dev/null || true
sleep 2

# Clear old controller log
> /var/log/adms/controller.log

# Start controller with REAL enforcement
/usr/local/bin/adms-controller \
    --sensor=inject \
    --tau=1s \
    --q=10 \
    --delta=3 \
    --http=:8080 \
    --log=/var/log/adms/controller.log &
CTRL_PID=$!
sleep 3

echo "" | tee -a "$LOG"
echo "--- Starting posture ---" | tee -a "$LOG"
curl -s http://localhost:8080/posture | tee -a "$LOG"
echo "" | tee -a "$LOG"

echo "" | tee -a "$LOG"
echo "--- Injecting ΔI (expect direct LOCKDOWN) ---" | tee -a "$LOG"
curl -s -X POST http://localhost:8080/inject -d '{"dimension": "I"}' | tee -a "$LOG"
echo "" | tee -a "$LOG"
sleep 3

echo "--- Posture after ΔI ---" | tee -a "$LOG"
# Note: this curl may fail if egress was quenched — that's expected
curl -s --max-time 2 http://localhost:8080/posture 2>&1 | tee -a "$LOG" || echo "(curl failed — expected under LOCKDOWN)" | tee -a "$LOG"
echo "" | tee -a "$LOG"

echo "" | tee -a "$LOG"
echo "--- LOCKDOWN active for 5 seconds ---" | tee -a "$LOG"

echo "TEST 1: rootfs read-only check:" | tee -a "$LOG"
if touch /tmp/adms-lockdown-test 2>&1; then
    echo "  /tmp writable (tmpfs — expected)" | tee -a "$LOG"
    rm -f /tmp/adms-lockdown-test
else
    echo "  /tmp not writable (rootfs remounted ro)" | tee -a "$LOG"
fi

echo "TEST 2: nftables lockdown rules:" | tee -a "$LOG"
nft list table inet adms 2>&1 | head -20 | tee -a "$LOG" || echo "  (nft query failed)" | tee -a "$LOG"

echo "TEST 3: cgroup freeze status:" | tee -a "$LOG"
cat /sys/fs/cgroup/user.slice/cgroup.freeze 2>&1 | tee -a "$LOG" || echo "  (cgroup freeze not available)" | tee -a "$LOG"

sleep 2

echo "" | tee -a "$LOG"
echo "--- AUTO BREAK-GLASS (5 seconds elapsed) ---" | tee -a "$LOG"

# Use break-glass script directly in case HTTP is blocked
/usr/local/sbin/adms-breakglass 2>&1 | tee -a "$LOG"
sleep 3

echo "" | tee -a "$LOG"
echo "--- VERIFY RECOVERY ---" | tee -a "$LOG"

echo "Posture after break-glass:" | tee -a "$LOG"
curl -s --max-time 5 http://localhost:8080/posture 2>&1 | tee -a "$LOG" || echo "(controller may have stopped)" | tee -a "$LOG"
echo "" | tee -a "$LOG"

echo "Write test after reset:" | tee -a "$LOG"
if touch /tmp/adms-recovery-test 2>&1; then
    echo "PASS: write access restored" | tee -a "$LOG"
    rm -f /tmp/adms-recovery-test
else
    echo "WARN: write still blocked" | tee -a "$LOG"
fi

echo "" | tee -a "$LOG"
echo "--- Controller log ---" | tee -a "$LOG"
cat /var/log/adms/controller.log 2>&1 | tee -a "$LOG"

# Clean up
kill $CTRL_PID 2>/dev/null || true
wait $CTRL_PID 2>/dev/null || true

echo "" | tee -a "$LOG"
echo "=== B10 Complete ===" | tee -a "$LOG"
echo "Full log: $LOG"
