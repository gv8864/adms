#!/bin/bash
# run-phase-C.sh
# Runs all Phase C evaluation metrics collection
# Run as: sudo bash run-phase-C.sh
set -euo pipefail

echo "============================================"
echo "ADMS Phase C: Full Evaluation (M1-M5)"
echo "============================================"
echo ""

echo ">>> C1: M1 Transition Correctness (S1-S4 + n=50 determinism)"
echo "    Estimated time: ~8 minutes"
echo "---"
bash C1-M1-transition-correctness.sh
echo ""
echo "Press Enter to continue to C2, or Ctrl+C to stop..."
read

echo ">>> C2: M3 Contraction Proxy"
echo "    Estimated time: instant"
echo "---"
bash C2-M3-contraction-proxy.sh
echo ""
echo "Press Enter to continue to C3, or Ctrl+C to stop..."
read

echo ">>> C3: M4 False Escalation Rate (200 cycles)"
echo "    Estimated time: ~10 minutes"
echo "---"
bash C3-M4-false-escalation.sh
echo ""
echo "Press Enter to continue to C4, or Ctrl+C to stop..."
read

echo ">>> C4: M5 Rollback Time and Stepwise Verification"
echo "    Estimated time: ~2 minutes"
echo "---"
bash C4-M5-rollback.sh
echo ""
echo "Press Enter to continue to C5, or Ctrl+C to stop..."
read

echo ">>> C5: Parameter Sensitivity Sweep"
echo "    Estimated time: ~15 minutes"
echo "---"
bash C5-parameter-sweep.sh

echo ""
echo "============================================"
echo "Phase C Complete — All Metrics Collected"
echo "============================================"
echo ""
echo "Results logs:"
echo "  /tmp/adms-C1-M1.log     (M1: transition correctness)"
echo "  /tmp/adms-C2-M3.log     (M3: contraction proxy)"
echo "  /tmp/adms-C3-M4.log     (M4: false escalation rate)"
echo "  /tmp/adms-C4-M5.log     (M5: rollback time)"
echo "  /tmp/adms-C5-sweep.log  (parameter sensitivity)"
echo ""
echo "Metrics JSON:"
echo "  /tmp/adms-C1-metrics.json"
echo "  /tmp/adms-C3-metrics.json"
echo "  /tmp/adms-C4-metrics.json"
echo "  /tmp/adms-sweep-*.json"
echo ""
echo "To collect all results into one file:"
echo "  cat /tmp/adms-C*.log > /tmp/adms-all-results.log"
