#!/bin/bash
# run-phase-B.sh
# Runs all Phase B enforcement tests in sequence
# Run as: sudo bash run-phase-B.sh
set -euo pipefail

echo "============================================"
echo "ADMS Phase B: Sensor Layer and Enforcement"
echo "============================================"
echo ""

echo ">>> B7: Dry-Run Enforcement"
echo "---"
bash B7-dry-run-enforcement.sh
echo ""
echo "Press Enter to continue to B8, or Ctrl+C to stop..."
read

echo ">>> B8: OBSERVE Enforcement (real audit rules, safe)"
echo "---"
bash B8-observe-enforcement.sh
echo ""
echo "Press Enter to continue to B9, or Ctrl+C to stop..."
read

echo ">>> B9: RESTRICTED Enforcement (blocks writes/egress)"
echo "---"
bash B9-restricted-enforcement.sh
echo ""
echo "Press Enter to continue to B10, or Ctrl+C to stop..."
read

echo ">>> B10: LOCKDOWN Enforcement (CAUTION)"
echo "---"
bash B10-lockdown-enforcement.sh

echo ""
echo "============================================"
echo "Phase B Complete"
echo "============================================"
echo ""
echo "Logs:"
echo "  /tmp/adms-B7.log"
echo "  /tmp/adms-B8.log"
echo "  /tmp/adms-B9.log"
echo "  /tmp/adms-B10.log"
echo ""
echo "To review all results:"
echo "  cat /tmp/adms-B*.log"
